#include<stdio.h>
#include<stdlib.h>

struct node{                       /*each node has the element, its rank and pointer to its parent*/
    int data;
    int rank;
    struct node* parent;
};

                                    /*initiating each node with element in it and rank to be 1 and parent pointer points to itself*/
struct node* newnode(int x){
    struct node* temp=(struct node*)malloc(sizeof(struct node));
    temp->data=x;
    temp->rank=1;
    temp->parent=temp;
    return temp;
};

int size;

struct node** create(){                /*creates required number of nodes and an array of pointers pointing to them*/
    int n;
    fgetc(stdin);
    scanf("%d",&n);
    fgetc(stdin);
    size=n;
    struct node** array=(struct node**)malloc(n*sizeof(struct node*));
    for(int i=0;i<n;i++){
        array[i]=newnode(i);
    }
    return array;
};

struct node* par(struct node* temp){    /*returns pointer to the representative element*/
    while(temp->parent!=temp){
        temp=temp->parent;
    }
    return temp;
};

void UNION(struct node** a){
    int x,y;
    fgetc(stdin);
    scanf("%d",&x);
    fgetc(stdin);
    scanf("%d",&y);
    fgetc(stdin);
    struct node* temp;
    struct node* temp1;
if(x<=size&&y<=size){                    /*performs union only if the elements are present in the sets*/
    temp=par(a[y-1]);
    temp1=par(a[x-1]);
    if(temp1->rank>temp->rank){          /*attaches the representative elements parent pointer to the representative element of the set with bigger rank*/
        temp->parent=temp1;
    }
    else if(temp1->rank<temp->rank){
        temp1->parent=temp;
    }
    else{                                /*if both ranks are equal increments the rank of the first set representative element by one*/
        temp->parent=temp1;
        temp1->rank=temp1->rank+1;
    }
}
else
    return;
}
struct node** clear(struct node** a){    /*clears all the elements in the array points it to null*/
    for(int i=0;i<size;i++){
            free(a[i]);
    }
    return NULL;
};
int main(){
    char digit;
    struct node **array=NULL;
    struct node *temp;
    while((digit=fgetc(stdin))!=EOF){
        if(digit=='N'){
            if(array!=NULL){
                array=clear(array);
            }
            array=NULL;
            array=create();
        }
        if(digit=='R'){
            int x;
            fgetc(stdin);
            scanf("%d",&x);
            fgetc(stdin);
            if(x>size) printf("-1\n");          /*prints rank only if element is in the set*/
            else{
                temp=array[x-1];
                printf("%d\n",temp->rank);
            }
        }
        if(digit=='U'){
            UNION(array);
        }
        if(digit=='S'){
            fgetc(stdin);
            int y;
            scanf("%d",&y);
            fgetc(stdin);
            if(y<=size){
                temp = par(array[y-1]);
                printf("%d\n",temp->data+1);
            }
            else
                printf("-1\n");
        }
        if(digit=='?'){
            fgetc(stdin);
            int a,b;
            scanf("%d",&a);
            fgetc(stdin);
            scanf("%d",&b);
            fgetc(stdin);
            if(a<=size&&b<=size){                    /*checks representative elements to check if they are present in the same set*/
                if(par(array[a-1])->data==par(array[b-1])->data) {
                        printf("1\n");
                }
                else
                    printf("0\n");
            }
            else
                printf("-1\n");
        }
    }
}
